function swapImage1(x,image){
    if (x==1){
        image.src =  '/AzurSkylark/images/img16-hoodie-black.png'
    }
    else if (x == 2){
        image.src =  '/AzurSkylark/images/img16-hoodie-front.png'
    }
}
function swapImage2(x,image){
    if (x==1){
        image.src =  '/AzurSkylark/images/img3-back.png'
    }
    else if (x == 2){
        image.src =  '/AzurSkylark/images/img3-front.png'
    }
}
function swapImage3(x,image){
    if (x == 1){
        image.src = '/AzurSkylark/Images/img6-black-back.png'
    }
    else if (x == 2){
        image.src = '/AzurSkylark/Images/img6-black-front.png'
    }
}
function swapImage4(x,image){
    if (x == 1){
        image.src = '/AzurSkylark/Images/img7-sweat-black-back.png'
    }
    else if (x == 2){
        image.src = '/AzurSkylark/images/img7-sweat-black.png'
    }
}
function swapImage5(x,image){
    if (x == 1){
        image.src = '/AzurSkylark/Images/img4-mask.png'
    }
    else if (x == 2){
        image.src = '/AzurSkylark/images/img4.png'
    }
}