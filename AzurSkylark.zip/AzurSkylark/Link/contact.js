function myFunction(){
    alert("Successfully sent");
}