const navLinks = document.getElementById("navLinks");

function navClose(){
    navLinks.style.top = "-200vh";
    navLinks.style.opacity = "0";
}
function navOpen(){
    navLinks.style.top = "0";
    navLinks.style.opacity = "1"
}